<?php
include '../login/sessao.php';
$dir = '../cadastro/upload/';
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <title>1Tostão - Serviços</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!-- LINK PARA AS ESTRELAS FUNCIONAREM-->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/usuario.css">
    <link rel="stylesheet" href="../css/style3.css">
    
  </head>
  <body style="background-color:#f1f1f1;">
  <header class="header fixed-top">
      <a href="../index.php"><div class="logo"><img src="../1tostao_logo.png" style="width:48px;"></div></a>
      <div class="menu-btn">
        <div class="menu-btn__lines"></div>
      </div>
      <ul class="menu-items">
        <li><a id = "a" href="#" class="menu-item">Home</a></li>
        <li>
          <a href="#" class="menu-item expand-btn">Categorias</a>
          <div class="mega-menu expandable">
            <div class="content">
              <div class="col">
                <section>
                  <h2>Featured 1</h2>
                  <!-- <a href="#" class="img-wrapper"><span class="img"><img src="https://picsum.photos/400?random=1" alt="Random Image" /></span></a> -->
                  <p>Lorem ipsum dolor sit amet.</p>
                </section>
              </div>
              <div class="col">
              <h2>Categorias</h2>
              <?php
                $sqli2 = "select * from categoria;";
                $result2 = conectar($sqli2);

                for($a = 0; $a < count($result2); $a++){
                  $cat = $result2[$a]['nome_cat'];
                  $idcat = $result2[$a]['id_categoria'];
                ?>
                <section>
                  <ul class="mega-links">
                    <li><a href="<?php echo  "categorias?id=".$idcat ?>"><?php echo $cat ?></a></li>
                  </ul>
                </section>
                <?php
                }
                ?>
            </div>
          </div>
		  </div>
        </li>
        <li><a id = "a" href="../sobre_nos/sobre nos.html" class="menu-item">Sobre Nós</a></li>
<?php if($logado != true){ 
  echo '<li><a id = "a" href="../cadastro/index.php" class="menu-item"><button class="btn btn-success">Cadastre-se</button></a></li>';
  }else{ ?>
    <li><a id = "a" href="../cadastro_servico/cadastro_servico.php" class="menu-item"><button class="btn btn-success">Cadastrar serviço</button></a></li>
    <?php
    }
    ?>
        <?php 
          $sqlImg = "select img_user from user where email = '$logado'";
          $resultado = conectar($sqlImg);
          $icon = 'https://i.imgur.com/orqbXp7.png';
          
          if(count($resultado) != 0){
            if($resultado[0]['img_user'] != null){
              $icon = $dir . $resultado[0]['img_user'];
            }
          }
          ?>

<!--colocar em um arquivo css-->
<style>
.logo:hover{
  animation: deg 2s ease-in-out infinite;
}

@keyframes deg{
  from{
  transform: rotate(360deg);
  }
}

.dropbtn {
  background-color: rgba(0,0,0,0);
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;

}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
  background-color: #f1f1f1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: rgba(0,0,0,0.2);
}

#cad_user:hover{
  background-color:rgba(14, 144, 20, 0.8);
}

#acc:hover{
  background-color:rgba(14, 144, 20, 0.8);
  color:#fff;
}

#deslogar:hover{
  background-color:rgba(14, 144, 20, 0.8);
  color:#fff;
}

</style>
<?php 
          $sqluser = "select * from user where email = '$logado'";
          $resultado2 = conectar($sqluser);
          
          if(count($resultado2) != 0){
            if($resultado2[0]['id_user'] != null){
              $id = $resultado2[0]['id_user'];
            }
          }
          
          
          ?>
          <li><a id = "a" href="../login/index.php" class="menu-item"><button class="btn btn-success">Logar</button></a></li>  
              <div class="dropdown" style="width:10%;">
                <button class="dropbtn"><img src="<?php echo $icon ?>" style="width:48px; height:48px; border-radius:100%;"></button>
                  <div class="dropdown-content">
                  <?php if(($resultado2) == null){ ?>
                  <ul><?php echo '<a id="cad_user" href="../cadastro/index.php">Criar uma conta</a>'; ?></ul>
                  <?php }else{ echo '<a id="acc" href="../usuario/index.php?id='.$id.'" >Minha conta</a><a id="deslogar" href="../login/logout.php?token='.md5(session_id()).'">Deslogar</a>'; }?>
                  </div>
                 </div>    
          </ul>
    </header>
    <br>
    <?php
		if(isset($_SESSION['msg'])){
			echo $_SESSION['msg']."<br><br>";
			unset($_SESSION['msg']);
		}
    ?>
        <div class="container jumbotron">
            <?php

              $id = $_GET['id'];
              $sql = 'select * from servicos where id_servico = '. $id;
              
              $retorno = conectar($sql);

              $nome = $retorno[0]['titulo'];
              $autor = $retorno[0]['autor'];
              $descricao = $retorno[0]['desc_servico'];
              $new_name = $retorno[0]['img_servico'];
              $dir = '../cadastro_servico/upload/';
              $dir2 = '../cadastro/upload/';
              $cat = $retorno[0]['sub_cat'];
              $valor = $retorno[0]['valor'];
              $btn = $retorno[0]['btn'];

              $sql_user = 'select * from user where id_user = ' . $autor;

              $user = conectar($sql_user);

              $usuario = $user[0]['nome'];
              $email = $user[0]['email'];
              $diruser = '../cadastro/upload/';
              $novo_nome = $user[0]['img_user'];
              $data = $user[0]['data'];
			  
			$sql2 = 'SELECT NOME_SUB_CAT, USER.EMAIL, VALOR, IMG_SERVICO, SERVICOS.* FROM SERVICOS INNER JOIN USER ON (AUTOR = ID_USER) INNER JOIN SUB_CATEGORIA ON (SUB_CAT = ID_SUB_CAT)';
			
			$conn = conectar($sql2);

			$categoria = $conn[0]['NOME_SUB_CAT'];
            ?>
            <h1 class="h1"><?php echo $nome ?></h1>
            <hr style="background-color:#f1f1f1; height:1px;">
            <div class="row">
                <div class="col-md-7">
                  <div id="demo" class="carousel slide" data-ride="carousel">

                    <!-- Indicators -->
                    <ul class="carousel-indicators">
                      <li data-target="#demo" data-slide-to="0" class="active"></li>
                      <li data-target="#demo" data-slide-to="1"></li>
                      <li data-target="#demo" data-slide-to="2"></li>
                    </ul>
                  
                    <!-- The slideshow -->
                    <div class="carousel-inner rounded">
                      <div class="carousel-item active">
                      <?php echo'<img src='. $dir.$new_name .' style="width:100%;">' ?>
                      </div>
                      <div class="carousel-item">
                        <?php echo'<img src='. $dir.$new_name .' style="width:100%;">' ?>
                      </div>
                      <div class="carousel-item">
                        <?php echo'<img src='. $dir.$new_name .' style="width:100%;">' ?>
                      </div>
                    </div>
                  
                    <!-- Left and right controls -->
                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
                      <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#demo" data-slide="next">
                      <span class="carousel-control-next-icon"></span>
                    </a>
                  </div>
                </div>
                  <div id="coluna" class="col-md-5">
                    <h4 style="text-align:center; padding-top:5%;"><?php echo $usuario ?></h4>
                    <hr>
					<div id="infocard" class="card">
						<div class="card-body">
							<?php echo'<p id="teste">'. $descricao . '</p>'?>
						</div>
					 </div>
           <button type="button" class="btn btn-success">Comprar por R$ <?php echo number_format($valor, 2, ',', '.' ) ?>
           <div style="color: none; background-color: none;">
              <?php 
              
                echo $btn;

              ?>
              </div>
            </button> 
					  <hr id="hrmidinfo" class="container">
		  <form method="POST" action="estrelas.php?id=<?php echo $id ?>" class="card-title" enctype="multipart/form-data">
			<div class="estrelas"> 
				<input type="radio" id="vazio" name="nota" value="" checked>

				<label for="estrela_um"><i class="fa fa-star"></i></label>
				<input type="radio" id="estrela_um" name="nota" value="1">
				
				<label for="estrela_dois"><i class="fa"></i></label>
				<input type="radio" id="estrela_dois" name="nota" value="2">
				
				<label for="estrela_tres"><i class="fa"></i></label>
				<input type="radio" id="estrela_tres" name="nota" value="3">
				
				<label for="estrela_quatro"><i class="fa"></i></label>
				<input type="radio" id="estrela_quatro" name="nota" value="4">
				
				<label for="estrela_cinco"><i class="fa"></i></label>
				<input type="radio" id="estrela_cinco" name="nota" value="5"><br>
				
				<input id="botaoavaliar" class="btn btn-warning" type="submit" style="width:120px;" value="Avaliar">
				
			</div>
		</form>
              </div>  
            </div>
            <hr>
  <div class="row">
    <div class="col-md-3">
      <i><p class="text-muted" style="text-align:center;">Voltar para a página principal</p></i>
		<a href="../index.php"><input type="button" id="pp" class="btn btn-primary" value="Voltar"></a>
	</div>
	  <div class="col-md-6">
	  </div>
      <!-- botao para enviar uma mensagem ao usuario abaixar o preço -->
      <div class="col-md-3" id="pech">
      <form method="POST" action="preco.php?id=<?php echo $id ?>" enctype="multipart/form-data">
      <i><p id="pre" class="text-muted">Achou o preço alto?</p></i>
        <button type="submit" id="pp2" name="preco" class="btn btn-success" value="Pechinchar">Pechinchar</button>      
      </form>
	</div>
  </div>
  </div>
        <script>
          function validaCampo(){
          var comentario = formuser.comment.value;
          if(comment == ""){
            alert("Escreva uma mensagem");
            return false;
          }
        }
        </script>

        <div class="container">
          <hr id="hrmid">
        </div>
		<div class="container jumbotron">
			<div class="row">
				<div class="col-md-12">
				<form method="POST" action="comentarios.php?id=<?php echo $id ?>" name="formuser">
        <!-- <h1 id="comment">Comentários</h1>
        <hr id="hrmid"> -->
				<textarea placeholder="escreva um comentário" type="text" class="rounded" id="comentario" name="comment" required></textarea>
				<input type="submit" id="sub" onclick="return validaCampo()" value="Enviar comentário"> 
				</form>
				</div>
			</div>
			<?php
      $sqlcomm = "SELECT * FROM comentarios INNER JOIN user on (user = id_user) inner join servicos on (servico = id_servico) where id_servico='$id' order by id_coment desc";
      $resultado3 = conectar($sqlcomm);
			?>
			<hr id="hrmid">
			<h4 id="comment">Comentários recentes</h4>
      <?php
      if($resultado3 == null){
        echo '<h3 class="text-muted" style="text-align:center; margin-top:35px;">Não há comentários, seja o primeiro a comentar!</h3>';
      }else{
      ?>
      <?php for($o = 0; $o<count($resultado3); $o++){
          $coment = $resultado3[$o]['comentario'];
          $name_user = $resultado3[$o]['nome'];
      ?>
				<div class="card" style="border-color:green;">
					<div class="card-body">
            <h4><b><?php echo $name_user ?></b></h4>
            <p><?php echo $coment ?></p>
					</div>
				</div><br>
			<?php } }?>
		</div>
    <?php
    $allcats = "SELECT NOME_SUB_CAT, USER.EMAIL, VALOR, IMG_SERVICO, SERVICOS.* FROM SERVICOS INNER JOIN USER ON (AUTOR = ID_USER) INNER JOIN SUB_CATEGORIA ON (SUB_CAT = ID_SUB_CAT) where nome_sub_cat like '%programacao%'";
    $linha = conectar($allcats);
    ?>
<div id="cont" class="container jumbotron">
        <div id="row1" class="row">
            <div class="col-md-6">
			
			 
			<?php if ($novo_nome == ""){echo '<img id="user" src='. 'https://pbs.twimg.com/profile_images/1273424234962976768/SzXkV_4b_400x400.jpg' . ' style="border-radius:1%;">'; 
			}else{
			echo '<img id="user" src='. $dir2.$novo_nome . ' style="border-radius:1%;">';
    }
				?>
			
                <hr>
                <div class="zoom">
                <a href="../registros_usuario/index.php?id=<?php echo $autor ?>"><button id="btnuser" type="button" class="btn rounded-pill btn-outline-success">Clique para ver mais serviços do usuário</button></a>
                </div>
            </div>
            <div id="info" class="col-md-6">
                <div id="carde" class="card">
                    <div class="card-body">
                        <h4 class="card-title text-dark">Informações sobre o usuário</h4>
                        <hr id="hrmid">
                        
                        <p id="ptext" class="text"><?php echo '- Olá, me chamo ' . $usuario ?></p>
						<p id="ptext" class="text"><?php echo '- Meu email é: ' .  $email . ' 📩' ?></p>
						<?php $data = strtotime($data); ?>
						<?php if($data == ""){ echo '<b>Data de entrada não registrada</b>';}else{ echo '<p>membro desde ' . date('d/m/Y',$data). '</p>';}?>
                    </div>
                </div>
            </div>
        </div>
    </div> 

      <hr>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="../jquery/js/script.js"></script>
    <script src="../jquery/lib/jquery-3.6.0.min.js"></script>
  </body>
</html>
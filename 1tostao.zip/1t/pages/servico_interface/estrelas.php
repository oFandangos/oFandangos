<?php
include '../login/sessao.php';
include_once("conexao.php");
$login = $logado;

if(!empty($_POST['nota'])){
	$estrela = $_POST['nota'];
    
    
    // $sql = "select * from servicos inner join classificacao on (autor = id_classificacao)";
    // $result = conectar($sql);
    // $id_servico = $result[0]['id_servico'];

    $sql = "select * from servicos inner join classificacao on (autor = id_classificacao);";
    $resultado = conectar($sql);

    $id = $_GET['id'];
    $sql2 = "SELECT * from servicos where id_servico = ".$id;
    $eco = conectar($sql2);
    $id_servico = $eco[0]['id_servico'];
    
	//Salvar no banco de dados
	$result_avaliacos = "INSERT INTO classificacao (nota, servico_id) VALUES ('$estrela', '$id_servico')";
	$resultado_avaliacos = mysqli_query($conn, $result_avaliacos);
	
	if(mysqli_insert_id($conn)){
        header("location: index.php?id=$id");
        $_SESSION['msg'] = "<p id='o' style='color:green; text-align: center; margin-bottom:-2%;'>Avaliação cadastrada com sucesso</p>";
	}else{
		$_SESSION['msg'] = "<p style='color:red; text-align:center;'>Erro ao avaliar serviço</p>";
		header("Location: index.php?id=$id");
	}
	
}else{
    $_SESSION['msg'] = "<p style='color:warning; text-align:center;'>Necessário selecionar pelo menos 1 estrela</p>";
	header("Location: index.php?id=$id");
}

?>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


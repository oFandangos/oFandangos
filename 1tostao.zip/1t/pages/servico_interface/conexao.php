<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "aluno";
	$dbname = "1tostao";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
    ?>
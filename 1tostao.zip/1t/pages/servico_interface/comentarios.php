<?php
include '../login/sessao.php';
include_once("conexao.php");
$login = $logado;

$comment = $_POST['comment'];

$id = $_GET['id'];

$sqlserv = "SELECT * FROM servicos where id_servico=".$id;
$conn = conectar($sqlserv);
$id_servico = $conn[0]['id_servico'];

$sqli = "select id_user from user where email = '$login';";

$result = conectar($sqli);
$id_user = $result[0]['id_user'];
if($logado != true){
    $_SESSION['msg'] = '<p style="color: red; text-align:center" margin-top:20px;">Você precisa fazer <a href="../login/index.php">login</a> para comentar</p>';
    // header("location: ../login/index.php");
    header("Location: index.php?id=$id");
}else{
$sql = "INSERT INTO comentarios (comentario,user,servico) values ('$comment',$id_user, $id_servico);";

$conn = new mysqli("localhost", "root", "aluno", "1tostao");
$conn->query($sql);
header("Location: index.php?id=$id");
$_SESSION['msg'] = '<p style="color: green; text-align:center; margin-bottom:-20px;">Comentário enviado com sucesso!</p>';
$conn->close();
}
//     if(mysqli_insert_id($conn)){
//         header("location: index.php?id=$id");
//         $_SESSION['msg'] = '<p style="color:green; text-align: center;">Comentário enviado com sucesso!</p>';
//     }else{
//         $_SESSION['msg'] = '<p style="color: red; text-align:center;">Erro ao enviar comentário</p>';
//         header("location: index.php?id=$id");
//     }
// }else{
//     $_SESSION['msg'] = '<h4 style="color:red; text-align: center;">Erro ao enviar comentário (mysql)</h4>';
// }
?>
<?php
include '../pages/login/sessao.php';
include("conexao.php");

$pesquisar = '';

$login = '';
if ($logado != null){
  $login = $logado;
} else {
  $login = null;
}

if($login == null){
  echo '';
}

$dir = 'cadastro/upload/';
$dir2 = 'cadastro_servico/upload/';
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
      integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA=="
      crossorigin="anonymous"
    />
    <!--css da pagina-->
    <link rel="stylesheet" href="style.css">    
    <link rel="stylesheet" href="../css/style3.css" /><!--menu-->
    <link rel="stylesheet" href="../css/style4.css">
    <title>1Tostão - Home</title>
    <!-- <link rel="stylesheet" href="../css/style2.css"> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css%22%3E">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300%7CMcLaren' rel='stylesheet' type='text/css' />
    <script type="text/javascript" src="jquery/js/modernizr.custom.79639.js"></script> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css%22%3E"/> 
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css%22%3E" />
  </head>
  <body class="bodyy" style="background-color:#eeeeee;">
    <header class="header fixed-top">
      <a href="index.php"><div class="logo"><img src="1tostao_logo.png" style="width:48px;"></div></a>
      <div class="menu-btn">
        <div class="menu-btn__lines"></div>
      </div>
      <ul class="menu-items">
        <li><a id = "a" href="#" class="menu-item">Home</a></li>
        <li>
          <a href="#" class="menu-item expand-btn">Categorias</a>
          <div class="mega-menu expandable">
            <div class="content">
              <div class="col">
                <section>
                  <h2>Featured 1</h2>
                  <!-- <a href="#" class="img-wrapper"><span class="img"><img src="https://picsum.photos/400?random=1" alt="Random Image" /></span></a> -->
                  <p>Lorem ipsum dolor sit amet.</p>
                </section>
              </div>
              <div class="col">
              <h2>Categorias</h2>
              <?php
                $sqli2 = "select * from categoria;";
                $result2 = conectar($sqli2);

                for($a = 0; $a < count($result2); $a++){
                  $cat = $result2[$a]['nome_cat'];
                  $idcat = $result2[$a]['id_categoria'];
                ?>
                <section>
                  <ul class="mega-links">
                    <li><a href="<?php echo  "categorias?id=".$idcat ?>"><?php echo $cat ?></a></li>
                  </ul>
                </section>
                <?php
                }
                ?>
            </div>
          </div>
		  </div>
        </li>
        <li><a id = "a" href="sobre_nos/sobre nos.html" class="menu-item">Sobre Nós</a></li>
<?php if($logado != true){ 
  echo '<li><a id = "a" href="cadastro/index.php" class="menu-item"><button class="btn btn-success">Cadastre-se</button></a></li>';
  }else{ ?>
    <li><a id = "a" href="cadastro_servico/cadastro_servico.php" class="menu-item"><button class="btn btn-success">Cadastrar serviço</button></a></li>
    <?php
    }
    ?>
        <?php 
          $sqlImg = "select img_user from user where email = '$logado'";
          $resultado = conectar($sqlImg);
          $icon = 'https://i.imgur.com/orqbXp7.png';
          
          if(count($resultado) != 0){
            if($resultado[0]['img_user'] != null){
              $icon = $dir . $resultado[0]['img_user'];
            }
          }
          ?>

<!--colocar em um arquivo css-->
<style>
.logo:hover{
  animation: deg 2s ease-in-out infinite;
}

@keyframes deg{
  from{
  transform: rotate(360deg);
  }
}

.dropbtn {
  background-color: rgba(0,0,0,0);
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;

}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
  background-color: #f1f1f1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: rgba(0,0,0,0.2);
}

#cad_user:hover{
  background-color:rgba(14, 144, 20, 0.8);
}

#acc:hover{
  background-color:rgba(14, 144, 20, 0.8);
  color:#fff;
}

#deslogar:hover{
  background-color:rgba(14, 144, 20, 0.8);
  color:#fff;
}

</style>
<?php 
          $sqluser = "select * from user where email = '$logado'";
          $resultado2 = conectar($sqluser);
          
          if(count($resultado2) != 0){
            if($resultado2[0]['id_user'] != null){
              $id = $resultado2[0]['id_user'];
            }
          }
          
          
          ?>
          <li><a id = "a" href="login/index.php" class="menu-item"><button class="btn btn-success">Logar</button></a></li>  
              <div class="dropdown" style="width:10%;">
                <button class="dropbtn"><img src="<?php echo $icon ?>" style="width:48px; height:48px; border-radius:100%;"></button>
                  <div class="dropdown-content">
                  <?php if(($resultado2) == null){ ?>
                  <ul><?php echo '<a id="cad_user" href="cadastro/index.php">Criar uma conta</a>'; ?></ul>
                  <?php }else{ echo '<a id="acc" href="usuario/index.php?id='.$id.'" >Minha conta</a><a id="deslogar" href="login/logout.php?token='.md5(session_id()).'">Deslogar</a>'; }?>
                  </div>
                 </div>    
          </ul>
    </header>
		<div class="hero-image">
  <div class="hero-text">
	<form class="form" method="GET" action="pesquisar.php" name="form_busca">
	<div class="row">
	<div class="col-md-12">
  <div class="zoom">
	<img id="imgtop" src="1tostao_logo.png" style="width:100px; padding-bottom: 2%;">
  </div>
	<h1 id="titletop" style="margin-bottom:1%;">Bem-Vindo(a) ao 1Tostão!</h1>
		<input id="titletop" type="text" class="rounded form-control" placeholder="O quê procura?" name="busca"><br>
		<button id="titletop" type="submit" class="rounded-pill btn btn-success">Pesquisar</button>
	</div>
	</div>
	</form>
  
		</div>
  </div>
		<style>
			body, html {
    height: 100%;
}

/* The hero image */
.hero-image {
  /* Use "linear-gradient" to add a darken background effect to the image (photographer.jpg). This will make the text easier to read */
  /* background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("abella.png") fixed; */
  background: linear-gradient(-45deg, #f1f1f1, #3CB371, #1E8449) no-repeat;
  background-size: 300% 300%;
  display: flex;
  animation: gradient 10s ease-in-out infinite alternate;
  height: 100%;
  
  /* Position and center the image to scale nicely on all screens (não utilizando ao colocar cores) */

  /* background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative; */
}

#titletop{
  animation: fadeIn 3s ease;
}

#imgtop{
  animation: turn 3s ease-in-out infinite alternate;
}

@keyframes gradient{
  from{
    background-position: 0 50%;
  }
  to{
    background-position: 100% 50%;
  }
}

@keyframes turn{
  0%{
    transform: rotateZ(0.03turn);
  }
  100%{
    transform: rotateZ(-0.03turn);
  }
}

@keyframes fadeIn{
  from{
    transform: translateY(50px);
    opacity:0;
  }
}

.hero-text{
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  width:50%;
  transform: translate(-50%, -50%);
  color: white;
}
		</style>
            <!--Custom styles for this template-->
            <link href="album.css" rel="stylesheet">
  <div class="container">
    <h2 style="margin-top:20px; text-align:center; color:green;">Serviços mais recentes</h2>
    <hr style="border:none; height:2px; margin-bottom:-20px; background-color:green;">
  <div class="album py-5">
            <div class="row">
          <?php
            $pagina_atual = filter_input(INPUT_GET,'pagina', FILTER_SANITIZE_NUMBER_INT);
            $pagina = (!empty($pagina_atual)) ? $pagina_atual : 1;
            $qnt_result_pg = 12;
            $inicio = ($qnt_result_pg * $pagina) - $qnt_result_pg;
            $sqli = "SELECT NOME_SUB_CAT, USER.EMAIL, VALOR, IMG_SERVICO, SERVICOS.* FROM SERVICOS INNER JOIN USER ON (AUTOR = ID_USER) INNER JOIN SUB_CATEGORIA ON (SUB_CAT = ID_SUB_CAT)  order by id_servico desc limit $inicio, $qnt_result_pg";
            $result = conectar($sqli);
            
            if($result != null){
              for($i = 0; $i < count($result); $i++){
                $new_name = $result[$i]['img_servico'];
                $titulo = $result[$i]['titulo'];
                $servico = $result[$i]['id_servico'];
                $autor = $result[$i]['EMAIL'];
                $valor = $result[$i]['VALOR'];
                $id_user = $result[$i]['autor'];
                $categoria = $result[$i]['NOME_SUB_CAT'];
            ?> 
            
<style>
.zoom{
    transition: all .2s;
    width: 100%;
}
.zoom:hover{
    transform: scale(1.1); 
}
</style>
  <?php
  //vai trazer os registros, se der erro, fazer um loop

  // alter table classificacao id_servico servico_id int not null; para fazer a alteração do nome da coluna no banco de dados
      $sql = "SELECT nota FROM classificacao where servico_id = ". $servico;
      $conectar = conectar($sql);


  // vai fazer o calculo da média das notas
      $conn = mysqli_connect('localhost','root','aluno','1tostao');
      $resultado = mysqli_query($conn, "SELECT sum(nota) FROM classificacao where servico_id = ".$servico);
      $linhas = mysqli_num_rows($resultado);

      while($linhas = mysqli_fetch_array($resultado)){
              
            $inteiro = count($conectar);
          if($inteiro == ""){
            break;
          }else{
            $divisao = $linhas['sum(nota)'] / $inteiro;
            $total = $divisao;
      }
    }
?>
<?php
//quantidade de avaliações
  $count = "SELECT * from classificacao where servico_id=".$servico;
  $conexao = conectar($count);
  $count2 = "SELECT count(*) as QTD from classificacao where servico_id =".$servico;
  $conexao2 = conectar($count2);

  if($conexao2 != null){
    for($b = 0; $b<count($conexao2); $b++){
      $quantidade = $conexao2[0]['QTD'];
    }
  }
?>
                <div class="col-md-4">
                  <div class="card mb-4 shadow-sm" id="row" style="border-color:rgb(43, 172, 22);">
                    <div class="zoom">
                    <a href="./servico_interface/index.php?id=<?php echo $servico ?>"><img class="img2 rounded-top" src="<?php echo $dir2.$new_name ?>"  style="height:260px; width: 100%;"></a>
                    </div>
                    <div class="card-body">
                      <a href="./servico_interface/index.php?id=<?php echo $servico ?>" class="especialidades text-success" style="font-size: 25px; text-decoration:none;"><b><?php echo $titulo ?></b></a><hr>
                      <p class="card-text"><b>Categoria:</b></p>
                      <p class="especialidades">- <?php echo $categoria ?><br></p>
                      <p class="contato2"><b>Contato</b></p>
                      <p class="contato" style="font-size: 13px;">📩   Email: <a href="registros_usuario/index.php?id=<?php echo $id_user ?>"><?php echo $autor ?> </p></a>
                      <p><b>Classificação: </b></p>
                      <p><?php if($inteiro != ""){echo '<i class="fa fa-star" aria-hidden="true" style="color:rgba(245, 233, 75, 0.945); margin-bottom:auto; margin-right: 2px;"></i> • '.round($total, 1) .' ('.$quantidade.' avaliações)</i>';}else{ echo '<i><p style="color:gray">esse serviço ainda não foi avaliado</p></i>';} ?></p>
                      <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group">
                          <button class="btn btn-sm btn-success"> <?php echo 'R$ '. $valor.',00'?> </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php
                }
                echo '<div class="col-md-12"><hr>';
                $result_pg = "SELECT COUNT(id_servico) AS num_result FROM servicos";
                $resultado_pg = mysqli_query($conn, $result_pg);
                $row_pg = mysqli_fetch_assoc($resultado_pg);
  
                //Quantidade de pagina
                $quantidade_pg = ceil($row_pg['num_result'] / $qnt_result_pg);
  
                //Limitar os links de antes e depois
                $max_links = 2;
                echo "<ul class='pagination'>";
                echo "<li class='page-item'><a class='page-link' style='color:green;' href='index.php?pagina=1'>Primeira</a></li> ";
  
                for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++){
                  if($pag_ant >= 1){
                    echo "<li class='page-item'><a class='page-link' style='color:green;' href='index.php?pagina=$pag_ant'>$pag_ant</a></li> ";
                  }
                }
                echo "<li class='page-item active'><a class='page-link' style='background-color:green;' href='#'>$pagina</a></li> ";
  
                for($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++){
                  if($pag_dep <= $quantidade_pg){
                    echo "<li class='page-item'><a class='page-link' style='color:green;' href='index.php?pagina=$pag_dep'>$pag_dep</a></li> ";
                  }
                }
                
                echo "<li class='page-item'><a class='page-link' style='color:green;' href='index.php?pagina=$quantidade_pg'>Ultima</a></li>"; 
                echo '</div>';
                echo '</ul>';
              }  
                else {
                
              echo '<h1 style="margin-left: auto; margin-right: auto; color: gray;">Não existem registros</h1>';
              }
                ?>                
              </div>
              </div>
              </div>
          
      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
</body>
</script>
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css%22%3E">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css%22%3E">
    <link rel="stylesheet" href="../css/style4.css">
    </script>
    <footer id="myFooter">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                  <img src="1tostao_logo.png" style="width:135px;">
                </div>
                <div class="col-sm-2">
                    <h5>Sobre nós</h5>
                    <ul>
                        <li><a href="#">Informações da Empresa</a></li>
                        <li><a href="#">Contato</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
                </div>
                <div class="col-sm-2">
                    <h5>Suporte</h5>
                    <ul>
                    <li style="cursor:pointer;">
                      FAQ
                    </li>

<!-- Modal -->
            <div class="modal fade" id="ExemploModalCentralizado" tabindex="-1" role="dialog" aria-labelledby="TituloModalCentralizado" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="TituloModalCentralizado" style="color:black; padding-left: 18px;text-align: center; width: 100%; margin: 0px 0">Apoie-nos!
                  </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body" style="color:black;">
                  <form action="https://www.paypal.com/donate" method="post" target="_top" style="text-align: center; width: 100%; margin: 0px 0">
                    <input type="hidden" name="business" value="RUCNQ9B3XZN2U" />
                    <input type="hidden" name="no_recurring" value="0" />
                    <input type="hidden" name="item_name" value="Ajuda para os desenvolvedores!" />
                    <input type="hidden" name="currency_code" value="BRL" />
                    <input type="image" src="https://www.paypalobjects.com/pt_BR/BR/i/btn/btn_donateCC_LG.gif" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Faça doações com o botão do PayPal" />
                    <img alt="" border="0" src="https://www.paypal.com/pt_BR/i/scr/pixel.gif" width="1" height="1" />
                  </form>
                  <div style="padding: 1rem;text-align: center; width: 100%; margin: 0px 0"><b>OU</b></div>
                  <img src="./img/QR_Code.png" style="text-align: center; margin: 0px 0; margin-left: 10.5rem;"/>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                  </div>
                </div>
              </div>
            </div>
          </li>
                        <li><a href="#">Telefones</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <div class="social-networks">
                        <a href="https://twitter.com" class="twitter"><i class="fab fa-twitter"></i></a>
                        <a href="https://facebook.com" class="facebook"><i class="fab fa-facebook"></i></a>
                        <a href="https://instagram.com" class="instagram"><i class="fab fa-instagram"></i></a>
                    </div>
                    <style>
                      .instagram:hover{
                        animation: fadeInsta 1s infinite ease-in-out alternate;
                      }
                      @keyframes fadeInsta{
                        0%{
                          color:red;
                        }
                        50%{
                          color:orange;
                        }
                        100%{
                          color:purple;
                        }
                      }
                    </style>
                    <a href="#">
                        <button type="button" class="btn btn-default" data-toggle="modal" data-target="#ExemploModalCentralizado">Apoie nosso trabalho!</button>
                        
                    </a>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <p>© 2021 Copyright - 1Tostão</p>
        </div>
    </footer>
    <script src="../jquery/js/script.js">
    <script src="../jquery/lib/jquery-3.6.0.min.js"></script>
    
</html>
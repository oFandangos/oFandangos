 <?php 

 include '../login/sessao.php';

 $id = $_GET['excluir'];
 $connect = new mysqli('localhost', 'root', 'aluno', '1tostao' );

          $removalDependency = "SET foreign_key_checks = 0;";
          $result = mysqli_query($connect,$removalDependency);
          $deleteQuery = "delete from user where id_user = ".$id;
          $result = mysqli_query($connect,$deleteQuery);
          $returnDependency = "SET foreign_key_checks = 1; ";
          $result = mysqli_query($connect,$returnDependency);
              

    
      ?>

      <html>

      <?php echo '<a id="deslogar" href="../login/logout.php?token='.md5(session_id()).'">Até</a>'; ?>
      </html>
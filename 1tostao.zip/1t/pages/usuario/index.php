<?php
include '../login/sessao.php';
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <title>1Tostão - Área do usuário</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="usuario.css">
    <link rel="stylesheet" href="../css/style3.css">
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body style="background-color:#e6e6e6">
  <header class="header fixed-top">
      <a href="../index.php"><div class="logo"><img src="../1tostao_logo.png" style="width:48px;"></div></a>
      <div class="menu-btn">
        <div class="menu-btn__lines"></div>
      </div>
      <ul class="menu-items">
        <li><a id = "a" href="#" class="menu-item">Home</a></li>
        <li>
          <a href="#" class="menu-item expand-btn">Categorias</a>
          <div class="mega-menu expandable">
            <div class="content">
              <div class="col">
                <section>
                  <h2>Featured 1</h2>
                  <!-- <a href="#" class="img-wrapper"><span class="img"><img src="https://picsum.photos/400?random=1" alt="Random Image" /></span></a> -->
                  <p>Lorem ipsum dolor sit amet.</p>
                </section>
              </div>
              <div class="col">
              <h2>Categorias</h2>
              <?php
                $sqli2 = "select * from categoria;";
                $result2 = conectar($sqli2);

                for($a = 0; $a < count($result2); $a++){
                  $cat = $result2[$a]['nome_cat'];
                  $idcat = $result2[$a]['id_categoria'];
                ?>
                <section>
                  <ul class="mega-links">
                    <li><a href="<?php echo  "categorias?id=".$idcat ?>"><?php echo $cat ?></a></li>
                  </ul>
                </section>
                <?php
                }
                ?>
            </div>
          </div>
		  </div>
        </li>
        <li><a id = "a" href="../sobre_nos/sobre nos.html" class="menu-item">Sobre Nós</a></li>
<?php if($logado != true){ 
  echo '<li><a id = "a" href="../cadastro/index.php" class="menu-item"><button class="btn btn-success">Cadastre-se</button></a></li>';
  }else{ ?>
    <li><a id = "a" href="../cadastro_servico/cadastro_servico.php" class="menu-item"><button class="btn btn-success">Cadastrar serviço</button></a></li>
    <?php
    }
    ?>
        <?php 
          $sqlImg = "select img_user from user where email = '$logado'";
          $resultado = conectar($sqlImg);
          $icon = 'https://i.imgur.com/orqbXp7.png';
          $dir = '../cadastro/upload/';
          if(count($resultado) != 0){
            if($resultado[0]['img_user'] != null){
              $icon = $dir . $resultado[0]['img_user'];
            }
          }
          ?>

<!--colocar em um arquivo css-->
<style>
.logo:hover{
  animation: deg 2s ease-in-out infinite;
}

@keyframes deg{
  from{
  transform: rotate(360deg);
  }
}

.dropbtn {
  background-color: rgba(0,0,0,0);
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;

}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
  background-color: #f1f1f1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: rgba(0,0,0,0.2);
}

#cad_user:hover{
  background-color:rgba(14, 144, 20, 0.8);
}

#acc:hover{
  background-color:rgba(14, 144, 20, 0.8);
  color:#fff;
}

#deslogar:hover{
  background-color:rgba(14, 144, 20, 0.8);
  color:#fff;
}

</style>
<?php 
          $sqluser = "select * from user where email = '$logado'";
          $resultado2 = conectar($sqluser);
          
          if(count($resultado2) != 0){
            if($resultado2[0]['id_user'] != null){
              $id = $resultado2[0]['id_user'];
            }
          }
          
          
          ?>
          <li><a id = "a" href="../login/index.php" class="menu-item"><button class="btn btn-success">Logar</button></a></li>  
              <div class="dropdown" style="width:10%;">
                <button class="dropbtn"><img src="<?php echo $icon ?>" style="width:48px; height:48px; border-radius:100%;"></button>
                  <div class="dropdown-content">
                  <?php if(($resultado2) == null){ ?>
                  <ul><?php echo '<a id="cad_user" href="../cadastro/index.php">Criar uma conta</a>'; ?></ul>
                  <?php }else{ echo '<a id="acc" href="../usuario/index.php?id='.$id.'" >Minha conta</a><a id="deslogar" href="login/logout.php?token='.md5(session_id()).'">Deslogar</a>'; }?>
                  </div>
                 </div>    
          </ul>
    </header>
  <?php

$dir = '../cadastro/upload/';

$id = $_GET['id'];
$sql = 'select * from user where id_user ='. $id;

$user = conectar($sql);

$usuario = $user[0]['nome'];
$email = $user[0]['email'];
$novo_nome = $user[0]['img_user'];
$password = $user[0]['senha'];
$data = $user[0]['data'];

$teste = "SELECT * FROM SERVICOS INNER JOIN USER ON (AUTOR = ID_USER) where id_user = " . $id;
$usern = conectar($teste);
$num_servicos = "SELECT COUNT(*) AS QTD FROM SERVICOS INNER JOIN USER ON (AUTOR = ID_USER) where id_user = " . $id;
$nums  = conectar($num_servicos);
$num = " você não possui serviços ";

if ($nums != null){
    for($i = 0; $i < count($nums); $i++){
        $num = $nums[0]['QTD'];

    } 
}
  ?>
<?php


?>

<div class="container" style="padding-top:6%;">
  <div class="row">
    <div class="col-lg-12">
      <h2 class="title-card text-sucess">Bem-Vindo(a) ao seu perfil, <?php echo $usuario . '!'?></h2>
      <div id="card" class="card">
        <div class="card-body">
        <div class="row">
          <div class="col-sm-5">
            <?php if ($novo_nome == null){ 
              echo '<img src="https://pbs.twimg.com/profile_images/1273424234962976768/SzXkV_4b_400x400.jpg"';
              }?>
          <img class="imguser rounded" src="<?php echo $dir.$novo_nome ?> ">
          </div>
          <div class="col-lg-7">
            <div id="carde" class="card">
            <h5 class="card-title" style="margin-top:3%; margin-bottom:-1%;">Informações da sua conta: </h5>
            <hr id="hrmid">
            <ul id="text">
              <?php if($num != 0){ ?>
                    você têm <a href="../registros_usuario/index.php?id=<?php echo $id?>"><?php echo '<b>'. $num .'</b>';?> serviços registrados.</a>
                      <?php }else{ ?>
                  Você não tem serviços registrados
                  <?php } ?></ul>
                    <ul id="text"><?php echo 'Seu E-mail: ' . $email?></ul>
                    <ul id="text"><?php echo 'Nome de usuário: ' . $usuario?></ul>
                    <ul id="text"><?php echo 'Senha: ' . $password?></ul>
                    <?php $data = strtotime($data); ?>
                    <ul id="text"><?php echo 'Membro desde: ' . date('d/m/Y', $data) ?></ul>
                    <ul id="text"><?php echo 'Sua ID de usuário: ' . $id?></ul>
                  </div>
	
			<div id="btn" class="card">
			<a href="../update_user/index.php?id=<?php echo $id ?>"><button id="tt" class="btn btn-primary">Alterar Informações de usuário</button></a><br>
			<a href="#"><button type="button" id="tt" class="btn btn-danger" data-toggle="modal" data-target="#exampleModalCenter">Excluir conta</button></a>
      
     <!-- Button trigger modal -->
      

      <!-- Modal -->
      <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLongTitle">Não nos abandone!</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              Tem certeza que deseja excluir sua conta? Essa ação não é reversível!
            </div>
            <div class="modal-footer">

            <form method="GET" action="excluir.php" >
              <button type="submit" name="excluir" value="<?php echo $id ?>" class="btn btn-danger"> Sim, excluir conta</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
            </form>
            </div>
          </div>
        </div>
      </div>

			</div>

          </div>
		      </div>
        </div>
      </div>
    </div>
  </div>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="../jquery/js/script.js"></script>
    <script src="../jquery/lib/jquery-3.6.0.min.js"></script>
  </body>
</html>
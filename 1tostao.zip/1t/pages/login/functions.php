<?php 

function conectar($consulta){

    $host = "localhost";
    $user = "root";
    $pass = "aluno";
    $banco = "1tostao";
    // criando uma conexão
    $connect = mysqli_connect($host, $user, $pass, $banco) or die ('Não foi possivel conectar');

    // executando o insert
    $result = mysqli_query($connect, $consulta);

    $matriz = array();
    $linha = 0;

    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
        $matriz[$linha] = $row;
        $linha = $linha + 1;
    }

    mysqli_free_result($result);

    return $matriz;
}
?>
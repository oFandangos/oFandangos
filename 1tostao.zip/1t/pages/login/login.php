<?php

session_start();

$email = $_POST['email'];
$senha = $_POST['senha'];

if (empty ($email and $senha )){
    echo "Por favor, preencha todos os campos";

} else { 

    $sql = "select email, senha from user where email = '$email' and senha = '$senha';";

    $host = "localhost";
    $user = "root";
    $pass = "aluno";
    $banco = "1tostao";
    // criando uma conexão
    $connect = mysqli_connect($host, $user, $pass, $banco) or die ('Não foi possivel conectar');

    // executando o insert
    $result = mysqli_query($connect, $sql);

    $row = mysqli_num_rows($result);
   

    if ($row == 1) {

        $resultado = mysqli_fetch_assoc($result);

        $_SESSION['email'] = $email;
        $_SESSION['senha'] = $senha;
        echo 'Login efetuado com sucesso!';        
        header('location:sessao.php');

        exit;
    } else {
        
        unset ($_SESSION['email']);
        unset ($_SESSION['senha']);
        echo 'Email ou senha incorretos';
        // echo '<h4 style="text-align:center; color:red; margin-top:20px;">Email ou Senha incorretos</h4>';
        // $_SESSION['msg'] = '<p style="text-align:center;">Email ou senha incorreto</p>';
    }
} 


?>
<?php
include '../login/sessao.php';
include_once("../conexao.php");

$pesquisar = '';

$login = '';
if ($logado != null){
  $login = $logado;
} else {
  $login = null;
}

if($login == null){
  echo '';
}

$dir = '../cadastro/upload/';
$dir2 = '../cadastro_servico/upload/';

?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
      integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA=="
      crossorigin="anonymous"
    />
    <!--css da pagina-->
    <link rel="stylesheet" href="style.css">    
    <link rel="stylesheet" href="../css/style3.css" /><!--menu-->
    <title>1Tostão - Home</title>
    <!-- <link rel="stylesheet" href="../css/style2.css"> -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css%22%3E">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300%7CMcLaren' rel='stylesheet' type='text/css' />
        <script type="text/javascript" src="jquery/js/modernizr.custom.79639.js"></script> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body style="background-color:#eeeeee;">
  <header id="header" class="header sticky-top">
      <a href="../index.php"><div class="logo"><img src="../1tostao_logo.png" style="width:48px;"></div></a>
      <div class="menu-btn">
        <div class="menu-btn__lines"></div>
      </div>
      <ul class="menu-items">
        <li><a id = "a" href="#" class="menu-item">Home</a></li>
        <li>
          <a href="#" class="menu-item expand-btn">Categorias</a>
          <div class="mega-menu expandable">
            <div class="content">
              <div class="col">
                <section>
                  <h2>Featured 1</h2>
                  <!-- <a href="#" class="img-wrapper"><span class="img"><img src="https://picsum.photos/400?random=1" alt="Random Image" /></span></a> -->
                  <p>Lorem ipsum dolor sit amet.</p>
                </section>
              </div>
              <div class="col">
              <h2>Featured 2</h2>
              <?php
                $sqli2 = "select * from categoria;";
                $result2 = conectar($sqli2);

                for($a = 0; $a < count($result2); $a++){
                  $cat = $result2[$a]['nome_cat'];
                  $idcat = $result2[$a]['id_categoria'];
                ?>
                <section>
                  <ul class="mega-links">
                    <li><a href="<?php echo  "../categorias?id=".$idcat ?>"><?php echo $cat ?></a></li>
                  </ul>
                </section>
                <?php
                }
                ?>
            </div>
          </div>
		  </div>
        </li>
        <li><a id = "a" href="../sobre_nos/sobre nos.html" class="menu-item">Sobre Nós</a></li>
<?php if($logado != true){ 
  echo '<li><a id = "a" href="../cadastro/index.php" class="menu-item"><button class="btn btn-success">Cadastre-se</button></a></li>';
  }else{ ?>
    <li><a id = "a" href="../cadastro_servico/cadastro_servico.php" class="menu-item"><button class="btn btn-success">Cadastrar serviço</button></a></li>
    <?php
    }
    ?>
        <?php 
          $sqlImg = "select img_user from user where email = '$logado'";
          $resultado = conectar($sqlImg);
          $icon = 'https://i.imgur.com/orqbXp7.png';
          
          if(count($resultado) != 0){
            if($resultado[0]['img_user'] != null){
              $icon = $dir . $resultado[0]['img_user'];
            }
          }
          ?>
<?php 
          $sqluser = "select * from user where email = '$logado'";
          $resultado2 = conectar($sqluser);
          
          if(count($resultado2) != 0){
            if($resultado2[0]['id_user'] != null){
              $id = $resultado2[0]['id_user'];
            }
          }
          ?>
          <li><a id = "a" href="../login/index.php" class="menu-item"><button class="btn btn-success">Logar</button></a></li>  
              <div class="dropdown" style="width:10%;">
                <button class="dropbtn"><img src="<?php echo $icon ?>" style="width:48px; height:48px; border-radius:100%;"></button>
                  <div class="dropdown-content">
                  <?php if(($resultado2) == null){ ?>
                  <ul><?php echo '<a id="cad_user" href="../cadastro/index.php">Criar uma conta</a>'; ?></ul>
                  <?php }else{ echo '<a id="acc" href="../usuario/index.php?id='.$id.'" >Minha conta</a><a id="deslogar" href="login/logout.php?token='.md5(session_id()).'">Deslogar</a>'; }?>
                  </div>
                 </div>    
          </ul>
    </header>
    <?php
$id = $_GET['id'];
$sqlcat = "SELECT * FROM CATEGORIA where id_categoria=".$id;
$catresult  = conectar($sqlcat);
$teste1 = $catresult[0]['nome_cat'];
?>

<div class="container" style="margin-top:8%;">
<h1 id="titulo">Serviços na categoria <?php echo $teste1 ?></h1>
<hr id="hrmid">
    <div class="row">
<?php
    $sqli = "SELECT NOME_SUB_CAT, CATEGORIA, USER.EMAIL, VALOR, IMG_SERVICO, SERVICOS.* FROM SERVICOS INNER JOIN USER ON (AUTOR = ID_USER) INNER JOIN SUB_CATEGORIA ON (SUB_CAT = ID_SUB_CAT) where categoria='$id' order by id_servico desc";
    $result = conectar($sqli);
    if($result != null){
        if($id == $result[0]['CATEGORIA']){
        for($i = 0; $i < count($result); $i++){
            $new_name = $result[$i]['img_servico'];
            $titulo = $result[$i]['titulo'];
            $servico = $result[$i]['id_servico'];
            $autor = $result[$i]['EMAIL'];
            $valor = $result[$i]['VALOR'];
            $categoria = $result[$i]['NOME_SUB_CAT'];

//vai trazer os registros, se der erro, fazer um loop

    $sql = "SELECT nota FROM classificacao where servico_id = ". $servico;
    $conectar = conectar($sql);

// vai fazer o calculo da média das notas
    $conn = mysqli_connect('localhost','root','aluno','1tostao');
    $resultado = mysqli_query($conn, "SELECT sum(nota) FROM classificacao where servico_id = ".$servico);
    $linhas = mysqli_num_rows($resultado);

    while($linhas = mysqli_fetch_array($resultado)){
            
          $inteiro = count($conectar);
        if($inteiro == ""){
          break;      
        }else{
          $divisao = $linhas['sum(nota)'] / $inteiro;
          $total = $divisao;
    }
  }

  $count = "SELECT * from classificacao where servico_id=".$servico;
  $conexao = conectar($count);
  $count2 = "SELECT count(*) as QTD from classificacao where servico_id =".$servico;
  $conexao2 = conectar($count2);

  if($conexao2 != null){
    for($b = 0; $b<count($conexao2); $b++){
      $quantidade = $conexao2[0]['QTD'];
    }
  }
?>
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm" id="row" style="border-color:rgb(43, 172, 22);">
        <div class="zoom">
        <a href="../servico_interface/index.php?id=<?php echo $servico ?>"><img class="img2 rounded-top" src="<?php echo $dir2.$new_name ?>"  style="height:260px; width: 100%;"></a>
        </div>
        <div class="card-body">
          <a href="../servico_interface/index.php?id=<?php echo $servico ?>" class="especialidades text-success" style="text-align: center; font-size: 25px;"><b><?php echo $titulo ?></b></a><hr>
          <p class="card-text"><b>Categoria:</b></p>
          <p class="especialidades">- <?php echo $categoria ?><br></p>
          <p class="contato2"><b>Contato</b></p>
          <p class="contato" style="font-size: 13px;">📩   Email: <a href="registros_usuario/index.php?id=<?php echo $id_user ?>"><?php echo $autor ?> </p></a>
          <p><b>Classificação: </b></p>
          <p><?php if($inteiro != ""){echo '<i class="fa fa-star" aria-hidden="true" style="color:rgba(245, 233, 75, 0.945); margin-bottom:auto; margin-right: 2px;"></i> • '.round($total, 1) .' ('.$quantidade.' avaliações)</i>';}else{ echo '<i><p style="color:gray">esse serviço ainda não foi avaliado</p></i>';} ?></p>
          <div class="d-flex justify-content-between align-items-center">
            <div class="btn-group">
              <button class="btn btn-sm btn-success"> <?php echo 'R$ '. $valor.',00'?> </button>
            </div>
          </div>
        </div>
      </div>
    </div>
              
        <?php
    }
      }  
        }
        ?>   
</div>
</div>
</body>
<script src="../jquery/js/script.js"></script>
<script src="../jquery/lib/jquery-3.6.0.min.js"></script>
</html>
<?php
include '../login/sessao.php';
?>

<!doctype html>
<html lang="en">
  <head>
    <title>1Tostão - Registros do usuário</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
  
  
  
  
  <div class="container">
  <h1 style="text-align: center; margin-top:2%;">SEUS REGISTROS:</h1>
  <hr style="border:1px solid rgb(0, 255, 42);">
                <div class="row">
      <?php
      $id = $_GET['id'];
        $sql = "SELECT NOME_SUB_CAT, USER.EMAIL, VALOR, IMG_SERVICO, SERVICOS.* FROM SERVICOS INNER JOIN USER ON (AUTOR = ID_USER) INNER JOIN SUB_CATEGORIA ON (SUB_CAT = ID_SUB_CAT) WHERE ID_USER = ". $id;
        $result = conectar($sql);
        if($result != null){
            for($i = 0; $i < count($result); $i++){

                $dir2 = '../cadastro_servico/upload/';
                $new_name = $result[$i]['img_servico'];
                $titulo = $result[$i]['titulo'];
                $servico = $result[$i]['id_servico'];
                $autor = $result[$i]['EMAIL'];
                $valor = $result[$i]['VALOR'];
                $categoria = $result[$i]['NOME_SUB_CAT'];

                if(count($result) < 3){
                echo '
                <div class="col-md-6">
                <div class="card mb-4 shadow-sm" style="border-color:rgb(43, 172, 22);">
                  <div class="zoom">
                  <a href="../servico_interface/index.php?id='. $servico.'"><img class="img2" src="'.$dir2.$new_name.'"  style="height:260px; width: 100%;"></a>
                  </div>
                  <div class="card-body">
                    <a href="../servico_interface/index.php?id='.$servico.'" class="especialidades text-success" style="text-align: center; font-size: 25px;"><b>'.$titulo.'</b></a><hr>
                    <p class="card-text"><b>Categoria:</b></p>
                    <p class="especialidades">- '.$categoria.'<br></p>
                    <p class="contato2"><b>Contato</b></p>
                    <p class="contato" style="font-size: 13px;">📩   Email:  '.$autor.' </p>
                    <p><b>Classificação: </b></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="btn-group">
                        <button type="button" class="btn btn-sm btn-success"> R$ '.$valor.',00'. '</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>';
            }
        }
    }
        ?>
        <div class="container">
            <div class="row">
            <?php
            for($a = 0; $a < count($result); $a++){
                $dir2 = '../cadastro_servico/upload/';
                $new_name = $result[$a]['img_servico'];
                $titulo = $result[$a]['titulo'];
                $servico = $result[$a]['id_servico'];
                $autor = $result[$a]['EMAIL'];
                $valor = $result[$a]['VALOR'];
                $categoria = $result[$a]['NOME_SUB_CAT'];
                if(count($result) >= 3){
                    echo '
				<div class="col-md-4">
                <d class="card mb-4 shadow-sm" style="border-color:rgb(43, 172, 22);">
                  <div class="zoom">
                  <a href="../servico_interface/index.php?id='. $servico.'"><img class="img2" src="'.$dir2.$new_name.'"  style="height:260px; width: 100%;"></a>
                  </div>
                  <di class="card-body">
                    <a href="../servico_interface/index.php?id='.$servico.'" class="especialidades text-success" style="text-align: center; font-size: 25px;"><b>'.$titulo.'</b></a><hr>
                    <p class="card-text"><b>Categoria:</b></p>
                    <p class="especialidades">- '.$categoria.'<br></p>
                    <p class="contato2"><b>Contato</b></p>
                    <p class="contato" style="font-size: 13px;">📩   Email:  '.$autor.' </p>
                    <p><b>Classificação: </b></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="btn-group">
                        <button type="button" class="btn btn-sm btn-success"> R$ '.$valor.',00'. '</button>
                      </div>
                    </div>
              </div>';
            }
        }
        ?>
        
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<?php
include '../login/sessao.php';

?>
<!doctype html>
<html lang="pt-br">
  <head>
    <title>1Tostão - Atualizar Informações</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../css/style3.css">
  </head>
  <body style="background-color:#f1f1f1;">
<?php
$dir = '../cadastro/upload/';

$id = $_GET['id'];
$sql = 'select * from user where id_user ='. $id;

$user = conectar($sql);

$usuario = $user[0]['nome'];
$email = $user[0]['email'];
$novo_nome = $user[0]['img_user'];
$password = $user[0]['senha'];
$data = $user[0]['data'];
?>
<header class="header fixed-top">
      <a href="../index.php"><div class="logo"><img src="../1tostao_logo.png" style="width:48px;"></div></a>
      <div class="menu-btn">
        <div class="menu-btn__lines"></div>
      </div>
      <ul class="menu-items">
        <li><a id = "a" href="#" class="menu-item">Home</a></li>
        <li>
          <a href="#" class="menu-item expand-btn">Categorias</a>
          <div class="mega-menu expandable">
            <div class="content">
              <div class="col">
                <section>
                  <h2>Featured 1</h2>
                  <!-- <a href="#" class="img-wrapper"><span class="img"><img src="https://picsum.photos/400?random=1" alt="Random Image" /></span></a> -->
                  <p>Lorem ipsum dolor sit amet.</p>
                </section>
              </div>
              <div class="col">
              <h2>Featured 2</h2>
              <?php
                $sqli2 = "select * from categoria;";
                $result2 = conectar($sqli2);

                for($a = 0; $a < count($result2); $a++){
                  $cat = $result2[$a]['nome_cat'];
                  $idcat = $result2[$a]['id_categoria'];
                ?>
                <section>
                  <ul class="mega-links">
                    <li><a href="<?php echo "../categorias?id=".$idcat ?>"><?php echo $cat ?></a></li>
                  </ul>
                </section>
                <?php
                }
                ?>
            </div>
          </div>
		  </div>
        </li>
        <li><a id = "a" href="../sobre_nos/sobre nos.html" class="menu-item">Sobre Nós</a></li>
<?php if($logado != true){ 
  echo '<li><a id = "a" href="../cadastro/index.php" class="menu-item"><button class="btn btn-success">Cadastre-se</button></a></li>';
  }else{ ?>
    <li><a id = "a" href="../cadastro_servico/cadastro_servico.php" class="menu-item"><button class="btn btn-success">Cadastrar serviço</button></a></li>
    <?php
    }
    ?>
        <?php 
          $sqlImg = "select img_user from user where email = '$logado'";
          $resultado = conectar($sqlImg);
          $icon = 'https://i.imgur.com/orqbXp7.png';
          
          if(count($resultado) != 0){
            if($resultado[0]['img_user'] != null){
              $icon = $dir . $resultado[0]['img_user'];
            }
          }
          ?>

<!--colocar em um arquivo css-->
<style>
.logo:hover{
  animation: deg 2s ease-in-out infinite;
}

@keyframes deg{
  from{
  transform: rotate(360deg);
  }
}

.dropbtn {
  background-color: rgba(0,0,0,0);
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;

}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
  background-color: #f1f1f1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: rgba(0,0,0,0.2);
}

#cad_user:hover{
  background-color:rgba(14, 144, 20, 0.8);
}

#acc:hover{
  background-color:rgba(14, 144, 20, 0.8);
  color:#fff;
}

#deslogar:hover{
  background-color:rgba(14, 144, 20, 0.8);
  color:#fff;
}

</style>
<?php 
          $sqluser = "select * from user where email = '$logado'";
          $resultado2 = conectar($sqluser);
          
          if(count($resultado2) != 0){
            if($resultado2[0]['id_user'] != null){
              $id = $resultado2[0]['id_user'];
            }
          }
          
          
          ?>
          <li><a id = "a" href="../login/index.php" class="menu-item"><button class="btn btn-success">Logar</button></a></li>  
              <div class="dropdown" style="width:10%;">
                <button class="dropbtn"><img src="<?php echo $icon ?>" style="width:48px; height:48px; border-radius:100%;"></button>
                  <div class="dropdown-content">
                  <?php if(($resultado2) == null){ ?>
                  <ul><?php echo '<a id="cad_user" href="../cadastro/index.php">Criar uma conta</a>'; ?></ul>
                  <?php }else{ echo '<a id="acc" href="../usuario/index.php?id='.$id.'" >Minha conta</a><a id="deslogar" href="login/logout.php?token='.md5(session_id()).'">Deslogar</a>'; }?>
                  </div>
                 </div>    
          </ul>
    </header>
<div class="container">
    <div class="row">
        <div class="col-md-3">
        </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <?php echo '<h4 class="text-dark"> Selecione o(s) campo(s) que deseja alterar, ' . $usuario .'</h4>' ?>
                        <hr>
                        <form method="POST" action="update_user.php" name="formuser" enctype="multipart/form-data">
                            <input type="hidden" name="id" value=<?php echo $id ?>>
                            <label id="top">Nome</label>
                            <input id="inf" class="rounded" type="text" name="nome" placeholder="Digite nome de usuario" value=<?php echo $usuario ?>><br>
                            <label>E-mail</label>
                            <input id="inf" class="rounded" type="email" name="email" placeholder="Digite seu email" value=<?php echo $email ?>><br>
                            <label>Senha</label>
                            <input id="inf" class="rounded" type="text" name="senha" placeholder="Insira sua nova senha" value=<?php echo $password?>><br>
                            <hr>
                        <button type="submit" value="alterar" id="alterar" class="rounded btn btn-success" onclick="return validaSenha()">Alterar informações de usuário</button>
                    </div>
                </div>
<hr style="height:1px; background:rgb(33, 109, 33);">
                <form method="POST" action="update_user.php" name="formuser" enctype="multipart/form-data">
                  <div id="imgatt" class="col-lg-12">
                    <div class="card">
                      <div class="card-body">
                        <h3 id="h3">Atualizar foto de perfil</h3>
                        <hr>
                        <label id="labelimg">imagem de usuário:</label>
                        <input type="file" id="file" name="img_user" value="<?php echo $dir.$novo_nome ?>" style="outline:0; border:none;"><br>
                        <hr>
                        <button type="submit" value="alterar" id="alterar" class="rounded btn btn-success">Alterar foto de perfil</button>
                        <a href="../usuario/index.php?id=<?php echo $id ?>"><input type="button" id="voltar" value="Voltar" class="rounded btn btn-primary"></input></a>
                      </div>
                    </div>
                  </div>
                </form>
            </div>
        <div class="col-md-3">
        </div>
    </div>
</div>
    </form>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="../jquery/js/script.js"></script>
    <script src="../jquery/lib/jquery-3.6.0.min.js"></script>
  </body>
</html>
<?php
include '../login/sessao.php';

$login = $logado;

$sqli = "select id_user from user where email = '$login';";

$result = conectar($sqli);
$id=            $result[0]['id_user'];
$titulo=        $_POST['titulo'];
$categoria=     $_POST['sub_cat'];
$descricao=     $_POST['desc_servico'];
$valor=         $_POST['valor'];
$btn=         $_POST['btn_personal'];


if(isset($_FILES['img_servico']))
{
   $ext = strtolower(substr($_FILES['img_servico']['name'],-4)); //Pegando extensão do arquivo
   $new_name = md5(time()) . $ext; //Definindo um novo nome para o arquivo
   $dir = 'upload/'; //Diretório para uploads 
   move_uploaded_file($_FILES['img_servico']['tmp_name'], $dir.$new_name); //Fazer upload do arquivo
 

//titulos = nome do serviço
$sql = "insert into servicos (titulo, autor, desc_servico, img_servico, sub_cat, valor, btn) values ('$titulo', $id, '$descricao', '$new_name', '$categoria', '$valor', '$btn');";  
}
// criar uma conexão
$conn = new mysqli("localhost", "root", "aluno", "1tostao");
// executando o insert

$conn->query($sql);

$conn->close();

include 'cad_concluido.php';

?>
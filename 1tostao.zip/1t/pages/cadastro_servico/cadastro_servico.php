<?php
include '../login/sessao.php';
$login = $logado;
if ($login != null){
  $login;
} else {
  $login = null;
}
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <title>1Tostão - Cadastre seu serviço!</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script type="text/javascript">
        function validaCampo(){
            var nome = formuser.titulo.value;
            var descricao = formuser.desc_servico.value;
            var valor = formuser.valor.value;
            var imagem = formuser.img_servico.value;
            var tamanho = descricao.length;

            if(tamanho >= 499){
                alert('Maximo de caracteres possivel é 500!');
                return false;
            }

            if(nome == ""){
                alert('Informe o nome do serviço');
                formuser.titulo.focus();
                return false;
            }
            if(descricao == ""){
                alert('Informe a descrição do serviço.');
                formuser.desc_servico.focus();
                return false;
            }
            
            if(valor == 0 || valor <= 0){
                alert('O valor do serviço não pode ser 0.');
                formuser.valor.focus();
                return false;
                
            }
            
        }
    </script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/cadastro_servico.css">
  </head>
  <body>
    <div class="container">
        <div class="row">
            <!--vazio-->
            <div class="col-md-3">
            </div>

            <div class="col-md-6">
                <form class="form" method="POST" action="insert_servico.php" enctype="multipart/form-data" name="formuser">                
                    <div class="card">
                        <div class="card-top">
                            <img class="imglogin rounded-pill" src="../1tostao_logo.png">
                            <h2 class="titulo"> Cadastre seu serviço </h2>
                        </div>
            
                        <div class="card-group">
                            <label>Nome do serviço<b class="text-muted">*</b></label>
                            <input class="rounded" type="text" name="titulo" maxlength="60" placeholder="Insira o nome do serviço" required>
                        </div>

                        <!--Fazer botão para escolher categorias, ao clicar aparecer as categorias existentes.-->
                        <div class="card-group">
                            <label>Categoria<b class="text-muted">*</b></label>
                            <?php
                                $qry = "select * from sub_categoria;";
                            
                                $conexao = new mysqli("localhost", "root", "aluno", "1tostao");
                            
                                $resultado = mysqli_query($conexao, $qry);
                                echo '<div class="form-group">';
                                echo '<select id="catm" name="sub_cat" style="border-style:none"><br>';
                                while ($linha = $resultado->fetch_row()){
                                echo '<option value="' . $linha[0] . '">' . $linha[1] . '</option>';
                                }
                                echo '</select>';
                                echo '</div><br>';
                            ?>

                        </div>
            
                        <div class="card-group">
                            <label>Descrição do serviço</label>
                            <textarea id="msg" class="rounded" maxlength="60" type="text" name="desc_servico" maxlength="499" placeholder="Descreva sobre o seu serviço"></textarea>
                        </div>
            
                        <!--Fazer uma validação para ser inserido somente valor-->
                        
                        <div class="card-group">
                            <label>Valor<b class="text-muted">*</b></label>
                            <input class="rounded" type="number" name="valor" maxlength="20" placeholder="Insira o valor do seu serviço" required>
                        </div>

                        <div class="card-group">
                            <label>Botão Personalizado</label>
                            <textarea id="btn_personal" class="rounded" type="text" name="btn_personal" maxlength="3100" placeholder="Insira seu botão personalizado do PicPay, Paypal ou QR Code"></textarea>
                        </div>

                        <div class="card-group">
                            <label>Imagem</label>
                            <input style="border-color:transparent; border-radius:0px;" id="kekko" type="file" type="text" name="img_servico" maxlength="70" accept="image/*">
                            <i><p class="text-muted" style="padding-top:5px;">*Também aceitamos gifs ;)</p></i>
                        </div>                                
                        
                    <div class="zoom">
                        <div class="card-group btn">
                            <button type="submit" onclick="return validaCampo()"><b>Cadastrar serviço</b></button> 
                        </div>
                    </div>
                </form>
            </div>
            <!--vazio-->
            <div class="col-md-3">
            </div>

        </div>
    </div>    
    <br>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
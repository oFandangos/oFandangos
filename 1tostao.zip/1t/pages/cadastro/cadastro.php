<?php

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $cpf = $_POST['cpf'];

        if(isset($_FILES['img_user']))
        {
           $ext = strtolower(substr($_FILES['img_user']['name'],-4)); //Pegando extensão do arquivo
           $novo_nome = md5(time()) . $ext; //Definindo um novo nome para o arquivo
           $diruser = 'upload/'; //Diretório para uploads 
           move_uploaded_file($_FILES['img_user']['tmp_name'], $diruser.$novo_nome); //Fazer upload do arquivo
        
            $sql = "insert into user (nome, cpf, senha, email, tipo, img_user, data) values ('$nome','$cpf','$senha', '$email', 1, '$novo_nome', NOW());";
        }
// criar uma conexão
$conn = new mysqli("localhost", "root", "aluno", "1tostao");
// executando o insert

$conn-> query($sql);

$conn->close();
            // $host = "localhost";
            // $user = "root";
            // $pass = "aluno";
            // $banco = "1tostao";
            // // criando uma conexão
            // $connect = new mysqli ($host, $user, $pass, $banco);
        
            // // executando o insert
            // $connect->query($sql);
        
            // $connect->close();
        
            include 'sucesso.php'
        
?>
<?php
?>
<!doctype html>
<html lang="en">
  <head>
    <title>1Tostão - Login</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/cadastro.css">
  </head>

    <body>
    <div class="container">
        <div class="row">
            <!--vazio-->
            <div class="col-md-3">
            </div>

            <div class="col-md-6">
                <form class="form" action="cadastro.php" method="POST">
                    <div class="card">
                        <div class="card-top">
                        <h1 class="text-success">SUCESSO!</h1>
                            <img class="imglogin rounded-pill" src="https://i.imgur.com/6vh6wCE.png">
                            <h2 class="titulo"> Cadastre-se </h2>
                            <p><b>Crie sua Conta</b></p>
                        </div>
            
                        <div class="card-group">
                            <label>Nome</label>
                            <input class="rounded-pill" type="nome" name="nome" placeholder="Digite seu Nome" required>
                        </div>
            
                        <div class="card-group">
                            <label>Email</label>
                            <input class="rounded-pill" type="email" name="email" placeholder="Digite seu Email" required>
                        </div>
            
                        <div class="card-group">
                            <label>Senha</label>
                            <input class="rounded-pill" type="password" name="senha" placeholder="Crie uma Senha"required>
                        </div>
            
                        <div class="card-group">
                            <label>CPF</label>
                            <input class="rounded-pill" type="text" name="cpf" placeholder="CPF"required>
                        </div>
                        
                        <div class="card-group">
                                <label><input type="checkbox">Lembre-me</label>
                        </div>

                    <div class="zoom">
                        <div class="card-group btn">
                            <button type="submit"><b>Cadastrar-se</b></button> 
                        </div>
                    </div>

                    <div style="font-weight:400; opacity: 0.8;" class="card-group">
                        <p style="font-style: italic;">Já tem uma conta?<b id="teste"><a href="../login/index.php"> entre por aqui!</a> </b></p>
                    </div>
                </form>
            </div>
            <!--vazio-->
            <div class="col-md-3">

            </div>

        </div>
    </div>
    
    
    </body>
    </html>
      
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>